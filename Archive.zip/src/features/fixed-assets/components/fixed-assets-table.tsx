"use client"
import {useEffect, useState} from 'react'
import {RefreshCw, Plus, Pencil, Trash2, TrendingDown, Calculator} from 'lucide-react'
import {Button} from '@/components/ui/button'
import {Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter} from '@/components/ui/dialog'
import {Select, SelectContent, SelectItem, SelectTrigger, SelectValue} from '@/components/ui/select'
import {Label} from '@/components/ui/label'
import {apiClient} from '@/lib/api-client'
import {Badge} from '@/components/ui/badge'
import {Input} from '@/components/ui/input'
import {useFixedAssetsStore, type FixedAsset} from '../store/fixed-assets-store'
import {FixedAssetFormModal} from './fixed-assets-form-modal'
import {DisposeAssetModal} from './dispose-asset-modal'
import {toast} from 'sonner'

function formatCurrency(v: number) {
    return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        maximumFractionDigits: 0,
    }).format(v)
}

function formatDate(d: string) {
    return new Date(d).toLocaleDateString('id-ID', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    })
}

export function FixedAssetsTable() {
    const {assets, isLoading, fetchAssets, deleteAsset, setFilters, filters} = useFixedAssetsStore()

    const [search, setSearch] = useState('')
    const [formModalOpen, setFormModalOpen] = useState(false)
    const [disposeModalOpen, setDisposeModalOpen] = useState(false)
    const [selectedAsset, setSelectedAsset] = useState<FixedAsset | null>(null)
    const [depreciationModalOpen, setDepreciationModalOpen] = useState(false)
    const [depreciationYear, setDepreciationYear] = useState(new Date().getFullYear().toString())
    const [depreciationMonth, setDepreciationMonth] = useState((new Date().getMonth() + 1).toString())
    const [isCalculatingDepreciation, setIsCalculatingDepreciation] = useState(false)

    useEffect(() => {
        fetchAssets()
    }, [fetchAssets])

    const handleStatusChange = (value: string) => {
        setFilters({...filters, status: value === 'all' ? undefined : value})
    }

    const handleSearch = (value: string) => {
        setSearch(value)
        // Search is handled by filtering locally for now
    }

    const getStatusBadge = (status: string) => {
        switch (status) {
            case 'active':
                return <Badge className="bg-green-100 text-green-700 hover:bg-green-100">Aktif</Badge>
            case 'disposed':
                return <Badge variant="secondary">Dilepaskan</Badge>
            default:
                return <Badge variant="secondary">{status}</Badge>
        }
    }

    const handleEdit = (asset: FixedAsset) => {
        setSelectedAsset(asset)
        setFormModalOpen(true)
    }

    const handleDelete = async (asset: FixedAsset) => {
        if (!confirm(`Hapus aktiva "${asset.name}" (${asset.code})?`)) return

        try {
            await deleteAsset(asset.id)
        } catch (e) {
            // Error handled by store
        }
    }

    const handleDispose = (asset: FixedAsset) => {
        setSelectedAsset(asset)
        setDisposeModalOpen(true)
    }

    const handleFormClose = () => {
        setFormModalOpen(false)
        setSelectedAsset(null)
    }

    const handleDisposeClose = () => {
        setDisposeModalOpen(false)
        setSelectedAsset(null)
    }

    const handleCalculateDepreciation = async () => {
        setIsCalculatingDepreciation(true)
        try {
            const {data} = await apiClient.post(`/admin/fixed-assets/calculate-depreciation/${depreciationYear}/${depreciationMonth}`)
            toast.success(`Penyusutan ${depreciationMonth}/${depreciationYear} berhasil dihitung. ${data.data.assets_count} aset diproses.`)
            setDepreciationModalOpen(false)
            fetchAssets()
        } catch (e: any) {
            toast.error(e?.message)
        } finally {
            setIsCalculatingDepreciation(false)
        }
    }

    // Filter assets by search
    const filteredAssets = search
        ? assets.filter(
            a =>
                a.name.toLowerCase().includes(search.toLowerCase()) ||
                a.code.toLowerCase().includes(search.toLowerCase()) ||
                a.category.toLowerCase().includes(search.toLowerCase())
        )
        : assets

    // Calculate accumulated depreciation from acquisition_date to selected period
    const calculateAccumulatedDepreciation = (asset: FixedAsset) => {
        const acqDate = new Date(asset.acquisition_date)
        const periodDate = new Date(parseInt(depreciationYear), parseInt(depreciationMonth) - 1, 1)

        // If acquisition is after period, no depreciation
        if (acqDate > periodDate) {
            return 0
        }

        // Calculate months from acquisition to period (inclusive)
        const monthsOwned = Math.min(
            (periodDate.getFullYear() - acqDate.getFullYear()) * 12 +
            (periodDate.getMonth() - acqDate.getMonth()) + 1,
            asset.useful_life_months
        )

        if (monthsOwned <= 0) {
            return 0
        }

        // Calculate monthly depreciation
        const depreciableAmount = asset.acquisition_cost - (asset.salvage_value || 0)
        const monthlyDep = depreciableAmount / asset.useful_life_months

        // Apply method-specific calculation
        switch (asset.depreciation_method) {
            case 'straight-line':
                return Math.round(monthlyDep * monthsOwned)

            case 'declining-balance': {
                // Calculate cumulative declining balance
                const rate = 2 / (asset.useful_life_months / 12)
                let bookValue = asset.acquisition_cost
                let accumulated = 0

                for (let i = 0; i < monthsOwned; i++) {
                    const monthlyAmount = bookValue * (rate / 12)
                    accumulated += monthlyAmount
                    bookValue -= monthlyAmount
                }

                return Math.round(accumulated)
            }

            case 'sum-of-years': {
                // Sum of Years Digits method
                const totalLife = asset.useful_life_months
                let accumulated = 0

                for (let i = 0; i < monthsOwned; i++) {
                    const remainingLife = totalLife - i
                    const sumOfYears = (totalLife * (totalLife + 1)) / 2
                    const yearlyDep = (remainingLife / sumOfYears) * depreciableAmount
                    accumulated += yearlyDep / 12
                }

                return Math.round(accumulated)
            }

            default:
                return Math.round(monthlyDep * monthsOwned)
        }
    }

    // Calculate summary using selected depreciation period
    const summary = {
        total_cost: assets.reduce((sum, a) => sum + a.acquisition_cost, 0),
        total_accumulated: assets.reduce((sum, a) => sum + calculateAccumulatedDepreciation(a), 0),
        total_book_value: assets.reduce((sum, a) => sum + (a.acquisition_cost - calculateAccumulatedDepreciation(a)), 0),
    }

    // Calculate per-row depreciation for display
    const getAssetDisplayDepreciation = (asset: FixedAsset) => {
        return calculateAccumulatedDepreciation(asset)
    }

    const getAssetDisplayBookValue = (asset: FixedAsset) => {
        const accumulated = calculateAccumulatedDepreciation(asset)
        return asset.acquisition_cost - accumulated
    }

    return (
        <div className="space-y-6">
            {/* Header */}
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-xl font-bold">Aktiva Tetap</h2>
                    <p className="text-sm text-muted-foreground">Fixed assets & depreciation</p>
                </div>
                <div className="flex gap-2">
                    <Button variant="outline" onClick={() => fetchAssets()} disabled={isLoading}>
                        <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`}/>
                        Refresh
                    </Button>
                    <Button variant="outline" onClick={() => setDepreciationModalOpen(true)} disabled={isLoading}>
                        <Calculator className="h-4 w-4 mr-2"/>
                        Hitung Penyusutan
                    </Button>
                    <Button onClick={() => setFormModalOpen(true)}>
                        <Plus className="h-4 w-4 mr-2"/>
                        Tambah
                    </Button>
                </div>
            </div>

            {/* Summary Cards */}
            {!isLoading && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">Total Harga Perolehan</p>
                        <p className="text-xl font-bold">{formatCurrency(summary.total_cost)}</p>
                    </div>
                    <div className="border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">Total Akumulasi Penyusutan</p>
                        <p className="text-xl font-bold text-orange-600">({formatCurrency(summary.total_accumulated)})</p>
                    </div>
                    <div className="border rounded-lg p-4">
                        <p className="text-sm text-muted-foreground">Total Nilai Buku</p>
                        <p className="text-xl font-bold text-green-600">{formatCurrency(summary.total_book_value)}</p>
                    </div>
                </div>
            )}

            {/* Filters */}
            <div className="flex gap-4 items-center">
                <Input
                    placeholder="Cari aset..."
                    value={search}
                    onChange={e => handleSearch(e.target.value)}
                    className="max-w-xs"
                />
                <Select
                    value={filters.status || 'all'}
                    onValueChange={v => v && handleStatusChange(v)}
                >
                    <SelectTrigger className="w-32">
                        <SelectValue placeholder="Status"/>
                    </SelectTrigger>
                    <SelectContent>
                        <SelectItem value="all">Semua</SelectItem>
                        <SelectItem value="active">Aktif</SelectItem>
                        <SelectItem value="disposed">Dilepaskan</SelectItem>
                    </SelectContent>
                </Select>
            </div>

            {/* Table */}
            <div className="border rounded-lg overflow-hidden">
                <table className="w-full text-sm">
                    <thead className="bg-muted/50">
                    <tr>
                        <th className="px-4 py-3 text-left font-medium">Kode</th>
                        <th className="px-4 py-3 text-left font-medium">Nama Aset</th>
                        <th className="px-4 py-3 text-left font-medium">Kategori</th>
                        <th className="px-4 py-3 text-left font-medium">Tgl Perolehan</th>
                        <th className="px-4 py-3 text-right font-medium">Harga Perolehan</th>
                        <th className="px-4 py-3 text-right font-medium">Penyusutan</th>
                        <th className="px-4 py-3 text-right font-medium">Nilai Buku</th>
                        <th className="px-4 py-3 text-center font-medium">Status</th>
                        <th className="px-4 py-3 text-center font-medium">Aksi</th>
                    </tr>
                    </thead>
                    <tbody>
                    {isLoading ? (
                        <tr>
                            <td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">
                                Memuat...
                            </td>
                        </tr>
                    ) : filteredAssets.length === 0 ? (
                        <tr>
                            <td colSpan={9} className="px-4 py-8 text-center text-muted-foreground">
                                Tidak ada data aktiva tetap
                            </td>
                        </tr>
                    ) : (
                        filteredAssets.map(asset => {
                            const displayAccumulated = getAssetDisplayDepreciation(asset)
                            const displayBookValue = getAssetDisplayBookValue(asset)
                            return (
                            <tr key={asset.id} className="border-b hover:bg-muted/50">
                                <td className="px-4 py-3 font-mono text-xs">{asset.code}</td>
                                <td className="px-4 py-3 font-medium">{asset.name}</td>
                                <td className="px-4 py-3">{asset.category}</td>
                                <td className="px-4 py-3">{formatDate(asset.acquisition_date)}</td>
                                <td className="px-4 py-3 text-right font-mono">{formatCurrency(asset.acquisition_cost)}</td>
                                <td className="px-4 py-3 text-right font-mono text-orange-600">
                                    ({formatCurrency(displayAccumulated)})
                                </td>
                                <td className="px-4 py-3 text-right font-mono font-medium text-green-600">
                                    {formatCurrency(displayBookValue)}
                                </td>
                                <td className="px-4 py-3 text-center">{getStatusBadge(asset.status)}</td>
                                <td className="px-4 py-3 text-center">
                                    <div className="flex items-center justify-center gap-1">
                                        {asset.status === 'active' && (
                                            <>
                                                <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    onClick={() => handleEdit(asset)}
                                                    title="Edit"
                                                >
                                                    <Pencil className="h-4 w-4"/>
                                                </Button>
                                                <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    onClick={() => handleDispose(asset)}
                                                    title="Lepaskan"
                                                    className="text-orange-600 hover:text-orange-700"
                                                >
                                                    <TrendingDown className="h-4 w-4"/>
                                                </Button>
                                                <Button
                                                    variant="ghost"
                                                    size="sm"
                                                    onClick={() => handleDelete(asset)}
                                                    title="Hapus"
                                                    className="text-red-600 hover:text-red-700"
                                                >
                                                    <Trash2 className="h-4 w-4"/>
                                                </Button>
                                            </>
                                        )}
                                    </div>
                                </td>
                            </tr>
                            )
                        })
                    )}
                    </tbody>
                </table>
            </div>

            {/* Depreciation Info */}
            <div className="border rounded-lg p-4 bg-muted/20">
                <h4 className="font-medium mb-2 flex items-center gap-2">
                    <TrendingDown className="h-4 w-4"/>
                    Metode Penyusutan
                </h4>
                <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>
                        <strong>Garis Lurus (Straight Line):</strong> (Harga Perolehan - Nilai Sisa) / Umur Ekonomis
                    </li>
                    <li>
                        <strong>Saldo Menurun (Declining Balance):</strong> Nilai Buku x (2 / Umur Ekonomis)
                    </li>
                    <li>
                        <strong>Jumlah Angka Tahun (Sum of Years):</strong> (Sisa Umur / Jumlah Angka Tahun) x (Harga
                        Perolehan - Nilai Sisa)
                    </li>
                </ul>
            </div>

            {/* Modals */}
            <FixedAssetFormModal
                open={formModalOpen}
                onClose={handleFormClose}
                editAsset={selectedAsset}
            />

            {selectedAsset && (
                <DisposeAssetModal
                    open={disposeModalOpen}
                    onClose={handleDisposeClose}
                    asset={selectedAsset}
                />
            )}

            {/* Calculate Depreciation Modal */}
            <Dialog open={depreciationModalOpen} onOpenChange={setDepreciationModalOpen}>
                <DialogContent className="max-w-sm">
                    <DialogHeader>
                        <DialogTitle>Hitung Penyusutan</DialogTitle>
                        <DialogDescription>
                            Hitung penyusutan bulanan untuk semua aset aktif
                        </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                        <div className="grid grid-cols-2 gap-4">
                            <div className="space-y-2">
                                <Label>Tahun</Label>
                                <Select value={depreciationYear} onValueChange={setDepreciationYear}>
                                    <SelectTrigger>
                                        <SelectValue/>
                                    </SelectTrigger>
                                    <SelectContent>
                                        <SelectItem
                                            value={(new Date().getFullYear() - 1).toString()}>{new Date().getFullYear() - 1}</SelectItem>
                                        <SelectItem
                                            value={new Date().getFullYear().toString()}>{new Date().getFullYear()}</SelectItem>
                                        <SelectItem
                                            value={(new Date().getFullYear() + 1).toString()}>{new Date().getFullYear() + 1}</SelectItem>
                                    </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label>Bulan</Label>
                                <Select value={depreciationMonth} onValueChange={setDepreciationMonth}>
                                    <SelectTrigger>
                                        <SelectValue/>
                                    </SelectTrigger>
                                    <SelectContent>
                                        {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12].map(m => (
                                            <SelectItem key={m} value={m.toString()}>
                                                {new Date(2024, m - 1).toLocaleDateString('id-ID', {month: 'long'})}
                                            </SelectItem>
                                        ))}
                                    </SelectContent>
                                </Select>
                            </div>
                        </div>
                    </div>
                    <DialogFooter>
                        <Button variant="outline" onClick={() => setDepreciationModalOpen(false)}>
                            Batal
                        </Button>
                        <Button onClick={handleCalculateDepreciation} disabled={isCalculatingDepreciation}>
                            {isCalculatingDepreciation ? 'Menghitung...' : 'Hitung Penyusutan'}
                        </Button>
                    </DialogFooter>
                </DialogContent>
            </Dialog>
        </div>
    )
}
